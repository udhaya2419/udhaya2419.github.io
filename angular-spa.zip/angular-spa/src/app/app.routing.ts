import { LoginComponent } from './components/login.component';
import { PageNotFoundComponent } from './components/pagenotfound.component';
import { Routes,RouterModule } from '@angular/router';
import { ServiceComponent } from './components/service.component';
import { AlwaysAuthGuard } from './services/alwaysauthguard';
import { ContactListComponent } from './components/contactlist.component';
import { ShowComponent } from './components/show.component';
import { NewContactComponent } from './components/newcontact.component';
import { UserLoadGaurd } from './services/userloadguard';



export const customRoutes: Routes =[
    {path:'',component:LoginComponent,canActivate:[AlwaysAuthGuard]},
    {path:'services',component:ServiceComponent},   
    {path:'contacts',component:ContactListComponent},  
    {path:'show/:selected',component:ShowComponent},  
    {path:'newcontact',component:NewContactComponent},  
    {path:'dynamic',
        loadChildren:() => import('./about/about.module').then
     (mod => mod.AboutModule),canLoad:[UserLoadGaurd]},
    {path:'**',component:PageNotFoundComponent}
   
];

export const SPAroutingModule = RouterModule.forRoot(customRoutes);