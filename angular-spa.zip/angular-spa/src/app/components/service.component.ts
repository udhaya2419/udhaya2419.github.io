import {Component, ViewEncapsulation} from '@angular/core';
@Component({
  template: `<h1 class="bg-warning">Corporate Training services</h1>
  <h5 class="mycolor">
   <div class="bg-success" >Technologies</div><br/>
   <ul>
      <li>Dotnet Core</li>
      <li>Angular js and Angular 2.0/4.0</li>
      <li>Node JS </li>
   </ul>
   </h5>
  `,
  styles: ['.mycolor {background: lightgrey}'],
  encapsulation:ViewEncapsulation.Emulated
})
//ViewEncapsulation in Angular 6:
// Emulated, Native, None, Shadow DOM

export class ServiceComponent{  
}