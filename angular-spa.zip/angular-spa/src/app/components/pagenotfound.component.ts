import { Component } from '@angular/core';


@Component({
    template:`
    <h2 class="bg-danger text-center text-warning">
    Sorry for the inconvinience..Page Not Found</h2>
    <h3> <a [routerLink]="['/']">Back</a></h3>
    `
})
export class PageNotFoundComponent{

}