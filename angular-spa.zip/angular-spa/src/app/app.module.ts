import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SPAroutingModule } from './app.routing';
import {FormsModule} from '@angular/forms';
import { LoginComponent } from './components/login.component';
import { PageNotFoundComponent } from './components/pagenotfound.component';
import { ServiceComponent } from './components/service.component';
import { NewContactComponent } from './components/newcontact.component';
import { ShowComponent } from './components/show.component';
import { ContactListComponent } from './components/contactlist.component';

@NgModule({
  declarations: [
    AppComponent,LoginComponent,PageNotFoundComponent,ServiceComponent,NewContactComponent,
    ShowComponent,ContactListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,SPAroutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
