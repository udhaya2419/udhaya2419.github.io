import { AboutComponent } from './about.component';
import { Route,RouterModule } from '@angular/router';


export const AboutRoutes: Route[] =[
    { path:'',component:AboutComponent,pathMatch:'full;'}
];

export default RouterModule.forChild(AboutRoutes);