import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import aboutRoute from './about.route';
import { AboutComponent } from './about.component';


@NgModule({
    imports:[
        CommonModule,aboutRoute
    ],
    declarations:[AboutComponent]
})
export class AboutModule{

}