import {SESSION} from './globals';
import {Injectable} from '@angular/core'
import { ActivatedRouteSnapshot, RouterStateSnapshot, CanLoad, UrlSegment}
             from "@angular/router";
import {Route,Router} from '@angular/router';

@Injectable({providedIn:'root'})
export class UserLoadGaurd implements CanLoad{
      // constructor(private _router:Router){ }   */
  canLoad( route: Route, segments: UrlSegment[]):boolean{
      
        console.log("I am UserLoadGaurd ");
    
    return false;
  }
}