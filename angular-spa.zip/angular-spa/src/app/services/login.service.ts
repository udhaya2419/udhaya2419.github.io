import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {User} from './user'

import {SESSION} from './globals';

//mock
var users = [
  new User('udhay','123'),
  new User('sachin','123')
];

@Injectable()
export class LoginService {
private authenticatedUser:User;

  constructor(  private _router: Router){} 

  login(user:User){
    //http.get(url,user)
    this.authenticatedUser = 
      users.find((u) => u.username === user.username);

    if (this.authenticatedUser && 
      this.authenticatedUser.password === user.password){
        
      window.localStorage.setItem("user",this.authenticatedUser.toString());
      //$rootScope
      SESSION.authenticated=true;
      SESSION.username=user.username;
      SESSION.jwttoken="lkfjdskjfsljfdsf kfklsdjfklsdfsfjsfj32jjk"
      SESSION.sessionID="123454646"

    this._router.navigate(['contacts']);  

      return true;
    }
    return false;

  }

logout() {
    localStorage.removeItem("user");
    this._router.navigate(['/']);
    SESSION.authenticated=false;
    SESSION.jwttoken=null
  }
  

  checkCredentials(){
    if (localStorage.getItem("user") === null){
        this._router.navigate(['/']);
    }
  }

}
