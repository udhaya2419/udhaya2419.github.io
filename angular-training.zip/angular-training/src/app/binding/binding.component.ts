import { Component } from '@angular/core';

@Component({
    selector:'app-binding',
    templateUrl:'./binding.component.html',
    styleUrls:['./binding.component.css']
})
export class BindingComponent{
    customer_name:string;
    constructor(){
        this.customer_name="Udhay"
    }
    
    clicked:boolean=false;
    buttonStatus:boolean=false;
    //JSON Array collection
    acctypes:any=[
        {name: 'Savings'},
        {name: 'Current'},
        {name: 'Corporate'}
    ];
    public clickedacctype:any = {name:''};

    //method - event hnadlers -functions
    onItemClicked(acctype:any){
        this.clickedacctype =acctype;
        this.clicked = true;
    }
    save({target}:any):void{
        this.buttonStatus=true;
        alert("Thanks for choosing account type:"+this.clickedacctype.name)
    }
}