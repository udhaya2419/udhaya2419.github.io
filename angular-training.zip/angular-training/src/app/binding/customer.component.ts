import { Component,Input } from '@angular/core';


@Component({
    selector:'app-customer',
    templateUrl:'./customer.component.html'
})
export class CustomerComponent{
@Input()
cname:string
}

