import { Product } from './product';
import { ProductService } from './product.service';
import { Component } from '@angular/core';


@Component({
    selector: 'app-DependencyInjection',
    templateUrl:'./product.component.html',
})
export class ProductComponent{
    product:Product;
    // constructor level DI
    constructor(public ps:ProductService){
        this.product =this.ps.getProduct();
    }
}