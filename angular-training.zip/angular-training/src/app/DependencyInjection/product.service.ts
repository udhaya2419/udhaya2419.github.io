import { Product } from './product';
import { Injectable } from '@angular/core';


@Injectable()
export class ProductService{
    getProduct(): Product{
        return new Product(107,"OnePlus","The Latest Phone",30000.00)
    }
}