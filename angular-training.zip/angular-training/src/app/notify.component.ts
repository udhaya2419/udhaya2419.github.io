import { Component } from '@angular/core';
import { Subscription } from 'rxjs';
import { MessageService } from './messageservices/message.service';


@Component({
    selector:'app-notify',
    template:`<div>
    <div class="container text-center">
        <div class="row">
            <div class="col-sm-8 offset-sm-2">
                <div *ngIf="message" class="bg-warning text-center">{{message.text}}</div>
                <router-outlet></router-outlet>
            </div>
        </div>
    </div>
  </div>`

    
})
export class NotifyComponent{

    message: any
    subscription: Subscription
  
    constructor(private messageService:MessageService){
  
    }
  
    ngOnInit(){
      console.log("Subscribed by NotifyComponent")
      this.subscription = this.messageService.getMessage().subscribe
      (message => { this.message = message;})
    }
  
    ngOnDestroy(){
      this.subscription.unsubscribe();
      console.log("Unsubscribed Message Service NotifyComponent")
    }
  }