import { Subject, Observable } from 'rxjs';
import { Injectable } from '@angular/core';


@Injectable({providedIn:'root'})
export class MessageService {
    private subject = new Subject<any>();

    //producer/provider
    sendMessage(message:string){
        this.subject.next({text:message});
   }

   clearMessage(){
       this.subject.next();
   }
    //consumer/SUbscriber
   getMessage():Observable<any>{
       return this.subject.asObservable();
   }
}