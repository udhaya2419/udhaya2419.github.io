import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms';

import {ContactListComponent} from 
      './components/contactlist.component';
import { ContactDetailsComponent } from 
      './components/contactdetails.component';
      
@NgModule({
  imports: [ CommonModule,FormsModule],
  declarations: [
  			ContactDetailsComponent,
  			ContactListComponent
  			],
  exports:[ContactListComponent]
})
export class ContactModule { }
