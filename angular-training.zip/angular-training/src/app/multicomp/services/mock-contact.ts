
import {Contact} from './contact';

// Model  - POJO - JSON array - State of App

//Application context - global
export const CONTACTS:Contact[] =[
{name:'Udhay', email:'udhay@gmail.com', phone:'2445678'},
{name:'Ram', email:'ram@gmail.com', phone:'3435678'},
{name:'Charan', email:'charan@gmail.com', phone:'34353678'}
]