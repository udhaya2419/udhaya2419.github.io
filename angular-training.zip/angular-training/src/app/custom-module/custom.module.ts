import { NgModule } from '@angular/core';
import { OutputComponent, PriceQuoterComponent, MailComponent } from './outputbinding';
import { CommonModule } from '@angular/common';



@NgModule({
    declarations:[
        OutputComponent,
        PriceQuoterComponent,
        MailComponent],
    imports:[
        CommonModule
    ],
    providers:[],
    exports:[
        OutputComponent
    ]
})
export class CustomModule{

}