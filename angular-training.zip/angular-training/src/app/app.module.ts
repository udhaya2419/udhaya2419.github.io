import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { BindingComponent } from './binding/binding.component';
import { FormsModule} from '@angular/forms';
import {ReactiveFormsModule} from '@angular/forms';
import { CustomerComponent } from './binding/customer.component';
import { CustomModule } from './custom-module/custom.module';
import { DIModule } from './DependencyInjection/di.module';
import { CompLifeCycleComponent, ChildComponent } from './lifecycle/complifecycle.component';
import { ContactModule } from './multicomp/contact.module';
import {HttpClientModule} from '@angular/common/http';
import { HttpComponent } from './http/http.component';
import { AgGridComponent } from './http/aggrid.component';
import { WeatherComponent } from './http/weather.component';
import {AgGridModule} from 'ag-grid-angular';
import { HomeComponent } from './home/home.component';
import { Routing } from './app.routing';
import { NotifyComponent } from './notify.component';


@NgModule({
  declarations: [
    AppComponent,HeaderComponent, InvoiceComponent,BindingComponent,
    CustomerComponent,CompLifeCycleComponent,ChildComponent,HttpComponent,AgGridComponent,
    WeatherComponent,HomeComponent,NotifyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,CustomModule,DIModule,ContactModule,
    HttpClientModule,ReactiveFormsModule,AgGridModule.withComponents([]),
    Routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }


