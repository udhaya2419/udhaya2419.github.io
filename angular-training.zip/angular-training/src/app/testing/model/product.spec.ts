import {Product} from './product';
describe('Product Model',() =>{


    it('Product verify - 101',() => {
        let p = new Product(101,"Keyboard",5000)
        expect(p).toBeTruthy();
        expect(p.pid).toEqual(101);
    });

});