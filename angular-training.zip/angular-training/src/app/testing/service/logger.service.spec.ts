import { TestBed } from '@angular/core/testing';

import { LoggerService } from './logger.service';

describe('LoggerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LoggerService = TestBed.get(LoggerService);
    expect(service).toBeTruthy();
  });

  it('Log message in DB',() => {
    const service:LoggerService = TestBed.get(LoggerService);
    const actual = service.LogInfo("Udhay")
    const expected ="Logged Udhay in DB";
    expect(actual).toEqual(expected);
  })
});
