import { MessageService } from '../messageservices/message.service';
import { Component } from '@angular/core';

@Component({
    templateUrl: 'home.component.html'
})
export class HomeComponent{

    constructor(private messageService:MessageService){

    }

    sendMessage(): void {

        this.messageService.sendMessage("Angular 9 is on the way !!!");
    }

    clearMessage(): void{
        this.messageService.clearMessage();
    }
}