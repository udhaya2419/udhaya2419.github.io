import { OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { MessageService } from './messageservices/message.service';
import { Component } from '@angular/core';

/*import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular world - Udhay';
}*/

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnDestroy{
  title = "Angular World"
  message: any
  subscription: Subscription

  constructor(private messageService:MessageService){

  }

  ngOnInit(){
    console.log("Subscribed by AppComponent")
    this.subscription = this.messageService.getMessage().subscribe
    (message => { this.message = message;})
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
    console.log("Unsubscribed Message Service")
  }
}

