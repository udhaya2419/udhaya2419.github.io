import { Component } from '@angular/core';

@Component({
    selector:'app-header',
    template:'<h1 class="bg-success text-center">{{title}}</h1>'
})
export class  HeaderComponent{
    title ='Bank of America'
}