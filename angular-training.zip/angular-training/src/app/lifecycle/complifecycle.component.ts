import { Component,Input,OnInit,OnChanges,DoCheck,
    OnDestroy,ChangeDetectorRef,SimpleChanges} from '@angular/core';



    @Component({
        selector:'app-lifecycle',
        template:`
        <h1 class="container"> Google Search:
        <input type="text" [(ngModel)]="search">
        </h1>
        <child [search]="search"></child>
        `
    })
    export class CompLifeCycleComponent{
        search: string ='computers';
    }


    @Component({
        selector: 'child',
        template: `
        <h1 class='text-danger container' id="txt">Search Text</h1>
        <div class='container'>
         <h3 class='text-primary' >{{search}}</h3>   
        </div>
          `
      })
      export class ChildComponent implements OnInit,OnChanges,DoCheck,OnDestroy{
        
          @Input()
          search:string;
          constructor(public cd:ChangeDetectorRef){
              console.log(`Constructor:${this.search}`)
              this.cd.detach();
          }
          ngOnInit(): void {
            console.log(`ngOnInit:${this.search}`) ; 
            
           /* setTimeout(() =>{
            this.cd.reattach()},5000);*/
          }

          ngOnChanges(changes: SimpleChanges): void {
                // validations,logging
                for (let key in changes) {
                  console.log(`${key} changed. 
                                     Current: ${changes[key].currentValue}.
                                     Previous: ${changes[key].previousValue}`);
                         }    
               // invoke service method to handle changes - model validation
                console.log(`ngOnChanges: ${this.search}`);     
                // ajax call to service to get live data 
                //var searchdata=http.get(url+"?q="+search)  
              } 
        ngAfterViewChecked(){
            console.log("ngAfterViewChecked:"+document.getElementById('txt').innerText)
        }
        ngDoCheck(): void {
            console.log("ngDoCheck - Chnage Detection STrategy")
            if(this.search.length==10){
                this.cd.detectChanges();
                console.log("detectChanges");
            }
            
        }
        ngOnDestroy(): void {
            console.log("Component Destroyed");
        }
      }

      